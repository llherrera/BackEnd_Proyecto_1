
const CTA = () => {
    return <button className={'cta'}>

    </button>
}

export default CTA;