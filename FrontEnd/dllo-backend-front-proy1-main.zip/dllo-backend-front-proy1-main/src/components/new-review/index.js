
import Component from "./Component"

export {Component as NewReview}