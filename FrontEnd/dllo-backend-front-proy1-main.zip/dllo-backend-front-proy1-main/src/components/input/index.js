
import Component from "./Component"

export {Component as Input}